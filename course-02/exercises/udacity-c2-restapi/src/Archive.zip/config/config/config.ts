export const config = {
  "dev": {
    "username": "udacitydbdev",
    "password": "qwer1234",
    "database": "udacitydbdev",
    "host": "udacitydbdev.czig7i9wto5o.us-east-1.rds.amazonaws.com",
    "dialect": "postgres",
    "aws_region": "us-east-2",
    "aws_profile": "default",
    "aws_media_bucket": "udacity-filestore-dev"
  },
  "prod": {
    "username": "",
    "password": "",
    "database": "udagram_prod",
    "host": "",
    "dialect": "postgres"
  },
  "jwt": {
       "secret": "heyheyhey"
  }
}
